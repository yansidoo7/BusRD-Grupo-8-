# Guía paso a paso – Trabajo Final BusRD (ISW-323)

Esta guía te dice **qué ejecutar, qué capturar y cómo explicarlo**. Tú te encargas de ejecutar, tomar las capturas y exponer; los scripts y el informe base ya están escritos.

---
## 0. Preparación (antes de tocar nada)
1. Instala **SQL Server 2022 (Developer o Express)** y **SSMS**.
2. Crea la carpeta `C:\Backups\BusRD\` (el script 08 intenta crearla; si falla, créala a mano y dale permisos de escritura a la cuenta del servicio *SQL Server (MSSQLSERVER)*).
3. Anota tus datos: **N° de grupo**, **ViajeID asignado**, **cédula** (`402` + 8 dígitos de grupo×1000).
4. En todos los scripts busca `<<< CAMBIAR` y reemplaza `@Grupo` y `@ViajeGrupo`.
   - El viaje debe estar **Programado** (para poder vender boletos). Compruébalo: `SELECT Estado FROM dbo.Viajes WHERE ViajeID = <tu viaje>;`
5. Crea un repositorio en GitHub/GitLab llamado `BusRD-Grupo<N>` con las carpetas `scripts/` y `evidencias/` y sube el README.

**Regla de oro de las capturas:** en cada una debe verse el script o la consulta y su resultado. Nómbralas con número: `01_...png`, `02_...png`.

---
## 1. Base entregada y línea base de rendimiento
1. Ejecuta `01_BusRD_base.sql` (1–3 min) y `02_sp_VenderBoleto_v0.sql`.
2. **Línea base pura (recomendado):** activa *Incluir plan de ejecución real* (Ctrl+M) y ejecuta las 3 consultas de `03_consultas_lentas.sql`, usando **tu viaje** en C1 y **tu cédula** en C2.
   - 📸 `01_base_filas_por_tabla.png` (resultado de la verificación del script 01)
   - 📸 `02_C1_original_plan.png`, `03_C1_original_io_time.png` (pestaña *Mensajes*)
   - 📸 `04_C2_original_plan.png`, `05_C2_original_io_time.png`
   - 📸 `06_C3_original_plan.png`, `07_C3_original_io_time.png`
3. Anota de los *Mensajes*: **lecturas lógicas** (`logical reads`) de cada tabla y **CPU time / elapsed time**.

---
## 2. E1 – Integridad (`scripts/01_integridad.sql`) · 1.5 pts
Ejecuta por secciones.
- 📸 `08_duplicados_detectados.png` (60 filas) y `09_pagos_huerfanos.png` (15 filas).
- 📸 `10_limpieza_verificacion.png` (todo en 0).
- 📸 `11_restricciones_creadas.png` – consulta sugerida: `SELECT name, type_desc FROM sys.objects WHERE type IN ('F','C','UQ') ORDER BY type;`
- 📸 `12_rechazo_duplicado.png` (mensaje "OK – Duplicado rechazado").

**Qué decir (decisiones):**
- *Duplicados:* se conserva el boleto vendido primero (el pasajero ya lo tenía) y el posterior se **anula** (no se borra: queda historial). Su pago se **revierte con monto negativo**.
- *Pagos huérfanos:* se mueven a `Pagos_Cuarentena` (auditoría) antes de eliminarlos de `Pagos`.
- *Índice único filtrado* `WHERE Estado='Activo'`: un boleto anulado libera el asiento. Es la defensa final del motor.
- `Monto <> 0` (no `> 0`) porque el reverso es negativo.

---
## 3. E2 – Concurrencia · 2.5 pts
### 3.1 Crear los procedimientos
Ejecuta `02_sp_VenderBoleto.sql` y `03_sp_AnularBoleto.sql`.
- 📸 `13_sp_validaciones.png` (los 6 mensajes de las pruebas rápidas).

### 3.2 Reproducir la doble venta con v0 (**antes** del índice único)
Abre **dos pestañas** de SSMS: `04_...sesionA.sql` y `05_...sesionB.sql`.
1. En A: ejecuta **PARTE 0** (quita temporalmente el índice único).
2. En A: ejecuta **PARTE 1**. **Inmediatamente** (<10 s) en B: ejecuta **PARTE 1**.
3. Cuando ambas terminen, en A ejecuta el SELECT de evidencia → verás **2 boletos activos para el mismo asiento**.
   - 📸 `14_v0_sesionA.png`, `15_v0_sesionB.png`, `16_v0_doble_venta.png`
4. En A: **PARTE 2** (anula el duplicado con `sp_AnularBoleto` y recrea el índice único).

### 3.3 Probar el procedimiento nuevo
1. En A: **PARTE 3**; en B (<10 s): **PARTE 3**.
2. Resultado esperado: A vende; B **espera ~10 s** (mira las horas impresas) y luego dice *"El asiento ya está vendido."*
   - 📸 `17_nuevo_sesionA.png`, `18_nuevo_sesionB_espera_y_rechazo.png`, `19_nuevo_sin_duplicados.png`
   - Opcional para el demo: durante la espera, en una tercera ventana ejecuta `EXEC sp_who2;` o `SELECT * FROM sys.dm_tran_locks WHERE request_session_id <> @@SPID;` para mostrar el bloqueo.

### 3.4 Qué explicar en el informe (por qué ocurre)
- Nivel de aislamiento por defecto: **READ COMMITTED**.
- Patrón *check-then-act*: A y B hacen el `IF EXISTS` (ambos ven "libre"), esperan, y luego ambos insertan. READ COMMITTED libera el bloqueo de lectura al terminar el SELECT y **no protege contra filas que aún no existen**.
- Anomalía: **condición de carrera / fila fantasma (phantom)**; el resultado es una **actualización perdida lógica** (doble reserva).
- Solución: `UPDLOCK` evita que dos sesiones tengan el bloqueo de lectura→escritura a la vez (sin deadlock S→X); `HOLDLOCK` (= SERIALIZABLE en esa tabla) toma **bloqueos de rango** sobre la clave (ViajeID, NumeroAsiento) aunque la fila no exista, y los mantiene hasta el `COMMIT`.
- Alternativa: `SET TRANSACTION ISOLATION LEVEL SERIALIZABLE`. Se prefiere el hint porque limita el efecto a una tabla y a una consulta, y bloquea menos.
- Cinturón y tirantes: el índice único filtrado garantiza la regla incluso si alguien escribe un INSERT sin pasar por el procedimiento.

---
## 4. E3 – Optimización (`scripts/06_...sql`) · 2.5 pts
Activa **Ctrl+M** y ejecuta sección por sección.
1. **A (línea base):** se desactiva temporalmente el índice único para medir C1 sin él. Capturas si no hiciste el paso 1.2.
2. **B:** crea los índices. 📸 `20_indices_creados.png`
3. **C:** consultas reescritas. 📸 planes e IO/TIME de C1, C2 y C3 *después* (`21_...` a `26_...`)
4. **D:** comparación de resultados. 📸 `27_mismo_resultado.png` (SoloEn... = 0)
5. **E:** impacto en escrituras. 📸 `28_impacto_escrituras.png`

**Tabla comparativa para el informe** (rellena con tus números):

| Consulta | Lecturas lógicas antes | Lecturas lógicas después | CPU antes (ms) | CPU después (ms) | Operador costoso antes → después |
|----------|----|----|----|----|----|
| C1 | | | | | Scan de Boletos → Index Seek |
| C2 | | | | | Scan de Clientes y Boletos → Seeks, sin Key Lookup |
| C3 | | | | | Scan de Boletos/Pagos → Index Seek por rango |

**Diagnóstico (para explicar):**
- **C1:** `NOT IN (SELECT … FROM Boletos WHERE ViajeID=… AND Estado=…)` sin índice por `ViajeID` → *Clustered Index Scan* de ~230 mil filas. El índice filtrado (ViajeID, NumeroAsiento) WHERE Estado='Activo' lo cubre y es pequeño. Se cambia `NOT IN` por `NOT EXISTS` (misma semántica porque `NumeroAsiento` es NOT NULL; además `NOT EXISTS` es robusto ante NULL).
- **C2:** `LTRIM(RTRIM(c.Cedula))` es **no sargable**: una función sobre la columna impide el *seek*. Se quita (la cédula no tiene espacios) y se usa el índice único de `Cedula`. `IX_Boletos_Cliente` con `INCLUDE` evita *Key Lookups*.
- **C3:** `YEAR(b.FechaVenta)=2025` es no sargable. Se cambia por rango `>= '20250101' AND < '20260101'`. Índice `(Estado, FechaVenta) INCLUDE (ViajeID)` y `Pagos(BoletoID) INCLUDE (Monto)`.
- **Índices vs escrituras:** cada índice extra se debe mantener en cada INSERT; mide la sección E y comenta el costo (normalmente pequeño) frente a la ganancia en lecturas. El índice único de integridad es obligatorio aunque cueste.
- **Si el plan de C3 sigue usando scan:** con ~medio año de datos el optimizador puede preferir recorrer el índice completo; explícalo (selectividad) y muestra la reducción de lecturas.

---
## 5. E4 – Seguridad (`scripts/07_seguridad.sql`) · 1.5 pts
Ejecuta y captura **cada bloque**.
- 📸 `29_taquilla_permitido.png` (venta por procedimiento + vista) y `30_taquilla_denegado.png` (mensajes *The SELECT permission was denied…*)
- 📸 `31_reportes_permitido.png` y `32_reportes_denegado.png` (Email/Telefono denegado)
- 📸 `33_admin.png`, `34_matriz_permisos.png`

**Explicar:**
- **Mínimo privilegio:** cada rol recibe solo lo necesario. Taquilla no ve tablas: solo ejecuta procedimientos y lee una vista.
- **Ownership chaining:** si el procedimiento/vista y las tablas tienen el **mismo propietario** (aquí `dbo`), SQL Server no vuelve a comprobar permisos sobre las tablas al ejecutar el procedimiento; solo exige `EXECUTE`. Por eso `u_taquilla` puede vender (INSERT en Boletos/Pagos) sin tener permiso sobre ellas. Se rompe con propietarios distintos, SQL dinámico o llamadas entre bases.
- Los usuarios `WITHOUT LOGIN` solo existen para pruebas; en producción serían usuarios mapeados a logins o grupos de AD.

---
## 6. E5 – Respaldo y recuperación (`scripts/08_...sql`) · 1.0 pt
Ejecuta **paso a paso** (no todo de una vez).
1. Paso 1: FULL. 📸 `35_recovery_full.png`
2. Pasos 2–6: backups y ventas. 📸 `36_backups_archivos.png` (carpeta con los 4 archivos) y `37_hora_anotada.png`
3. Pasos 7–8: el desastre. 📸 `38_delete_y_conteo_cero.png`
4. Paso 9: restauración con STOPAT. 📸 `39_restore_stopat.png`
5. Paso 10: verificación. 📸 `40_verificacion_8_boletos.png` (8 × EXISTE) y `41_conteos_comparados.png`
6. Pega la **política de respaldos** del Paso 11 en el informe (tabla).

**Explicar:**
- FULL permite backups de log y recuperación a un punto en el tiempo; con SIMPLE no.
- Cadena de restauración: FULL → DIFF → LOG1 (NORECOVERY) → LOG de cola con `STOPAT` y `RECOVERY`.
- *Tail-log*: respalda lo ocurrido desde el último backup de log, para no perder nada.
- Observa que un `DELETE` directo falló por la FK; para simular el desastre el script borra primero los pagos. Buen dato para la exposición.

**Problemas comunes:** *Access denied* en la carpeta (permisos del servicio); *log chain broken* (no hiciste el FULL tras cambiar a FULL); *STOPAT* posterior al último log (usa la hora anotada, no una posterior).

---
## 7. E6 – Informe y repositorio · 1.0 pt
1. El informe base está en el documento **"Informe Trabajo Final BusRD"**: reemplaza los `[CAPTURA …]` y `[X]` con tus datos, agrega las capturas y exporta a **PDF** (máx. 10 páginas sin portada ni anexos). Agrega portada y el **anexo con el aporte de cada integrante**.
2. Sube al repositorio los 8 scripts de `scripts/` (con tus valores de grupo) y las capturas en `evidencias/`.
3. **Prueba final:** crea la base desde cero con `01_BusRD_base.sql` y ejecuta todo en orden para confirmar que corre sin errores (los scripts 4/5 en dos ventanas). Si algo falla, no entregues sin corregirlo: vale 1 punto y afecta la demo.

---
## 8. Exposición (15–20 min, todos participan)
| Min | Contenido | Quién |
|-----|-----------|-------|
| 0–2 | Problema y alcance | Integrante 1 |
| 2–6 | Integridad + **demo doble venta con v0** | Integrante 1 |
| 6–11 | **Demo del bloqueo con el procedimiento nuevo** (dos ventanas) y explicación del aislamiento | Integrante 2 |
| 11–15 | **Una consulta optimizada con su plan** (antes/después) | Integrante 3 |
| 15–18 | Seguridad (acceso permitido/denegado) y respaldo (STOPAT) | repartido |
| 18–20 | Conclusiones | cualquiera |

**Consejos para la demo:** deja las dos ventanas ya abiertas con las variables ajustadas; ten el video de respaldo grabado (penaliza solo 0.5 si falla la demo); ensaya el timing de los 10 segundos.

### Preguntas probables
- **¿Por qué `HOLDLOCK` y no solo `UPDLOCK`?** Sin HOLDLOCK el bloqueo de rango no se mantiene; otra sesión podría insertar el asiento en el hueco.
- **¿Por qué no SERIALIZABLE para todo el procedimiento?** Bloquea más de lo necesario y reduce la concurrencia de otras ventas.
- **¿Un deadlock es posible?** Con UPDLOCK desde la primera lectura, las sesiones se serializan en vez de bloquearse mutuamente por conversión S→X.
- **¿Qué es sargable?** Una condición que permite usar un índice con *seek*; envolver la columna en una función lo impide.
- **¿Qué es un Key Lookup?** Ir al índice clustered por cada fila encontrada para traer columnas que el índice no tenía; se evita con `INCLUDE`.
- **¿Por qué filtrado el índice único?** Para que los anulados no cuenten y el asiento pueda venderse otra vez.
- **¿Qué pasa si falla el cobro a mitad del procedimiento?** `TRY…CATCH` hace `ROLLBACK`; boleto y pago son atómicos.
- **¿Cuál es el RPO de tu política?** Máximo 15 minutos (frecuencia del backup de log).

---
## 9. Antes de entregar – checklist
- [ ] Valores de grupo cambiados en todos los scripts.
- [ ] Todas las capturas numeradas en `evidencias/`.
- [ ] Informe en PDF ≤ 10 páginas (sin portada/anexos), con anexo de aportes.
- [ ] Scripts probados de principio a fin sobre una base nueva.
- [ ] Cada integrante puede explicar **cualquier línea** de los scripts (la IA está permitida solo si lo entiendes).
- [ ] Entrega **antes** de las exposiciones de la clase 5 (−2 pts por día de retraso).
