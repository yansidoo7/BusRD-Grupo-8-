# BusRD – Trabajo Final ISW-323 (Taller de Base de Datos III)

## Integrantes
| Nombre | Matrícula | Parte técnica que expone |
|--------|-----------|--------------------------|
| _(completar)_ | | |
| _(completar)_ | | |
| _(completar)_ | | |

## Datos asignados al grupo
- **Grupo N°:** _(completar)_
- **Viaje asignado (C1, demo y respaldo):** _(completar, `ViajeID`)_
- **Cédula usada en C2:** `402` + 8 dígitos de (N° grupo × 1000). Ej.: grupo 3 → cliente 3000 → `40200003000`
- En los scripts, buscar `<<< CAMBIAR` y reemplazar `@Grupo` y `@ViajeGrupo` por los valores del grupo.

## Requisitos
SQL Server 2022 (Developer/Express) + SSMS. Carpeta `C:\Backups\BusRD\` con permiso de escritura para el servicio de SQL Server.

## Orden de ejecución
| Paso | Script | Qué hace |
|------|--------|----------|
| 0 | `01_BusRD_base.sql` (del docente) | Crea la base y los datos (1–3 min) |
| 0 | `02_sp_VenderBoleto_v0.sql`, `03_consultas_lentas.sql` (del docente) | Procedimiento defectuoso y consultas lentas (línea base) |
| 1 | `scripts/01_integridad.sql` | Detecta y limpia datos sucios; FKs, CHECK, unicidades, índice único filtrado |
| 2 | `scripts/02_sp_VenderBoleto.sql` | Procedimiento de venta seguro (transacción + UPDLOCK/HOLDLOCK) |
| 3 | `scripts/03_sp_AnularBoleto.sql` | Anulación con reverso de pago negativo |
| 4 | `scripts/04_demo_concurrencia_sesionA.sql` | Demo de doble venta (v0) y bloqueo (nuevo) – ventana A |
| 5 | `scripts/05_demo_concurrencia_sesionB.sql` | Ídem – ventana B (ejecutar a menos de 10 s de A) |
| 6 | `scripts/06_indices_y_consultas_optimizadas.sql` | Índices, consultas reescritas, comparación y efecto en escrituras |
| 7 | `scripts/07_seguridad.sql` | Roles, vistas, usuarios de prueba y pruebas permitido/denegado |
| 8 | `scripts/08_respaldo_y_restauracion.sql` | FULL → DIFF → LOG → tail-log → restauración con STOPAT |

> Los scripts 4 y 5 se ejecutan manualmente en dos ventanas de SSMS (ver comentarios dentro de cada archivo).
> El script 4 elimina temporalmente el índice único para reproducir el problema y lo vuelve a crear.

## Evidencias
Capturas numeradas en `evidencias/` (ver lista en la guía).
